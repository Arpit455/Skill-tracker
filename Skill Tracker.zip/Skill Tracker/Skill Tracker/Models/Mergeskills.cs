﻿using SkillTracker.Model;

namespace Skill_Tracker.Models
{
    public class Mergeskills
    {
        public TechnicalSkillModel technicalSkill { get; set; }
        public NonTechnicalSkillModel nontechnicalSkill { get; set; }

    }
}
