﻿namespace Skill_Tracker.Models
{
    public class Admin
    {
        string Name { get; set; }
        int Id { get; set; }
    }
}
